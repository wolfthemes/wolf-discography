<?php
/**
 * Wolf Discography Uninstall
 *
 * Uninstalling Wolf Discography
 *
 * @author WolfThemes
 * @category Core
 * @package WolfDiscography/Uninstaller
 * @version 1.4.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}